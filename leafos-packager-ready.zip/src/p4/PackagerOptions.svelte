<script>
  import {onDestroy} from 'svelte';
  // Standard JSON can't represent values such as Infinity, which some options use.
  import * as ExtendedJSON from '@turbowarp/json';
  import {_} from '../locales/';
  import {slide, fade} from 'svelte/transition';
  import Section from './Section.svelte';
  import Button from '../p4/Button.svelte';
  import ImageInput from './ImageInput.svelte';
  import LearnMore from './LearnMore.svelte';
  import ColorPicker from './ColorPicker.svelte';
  import Downloads from './Downloads.svelte';
  import writablePersistentStore from './persistent-store';
  import fileStore from './file-store';
  import {progress, currentTask, error} from './stores';
  import Preview from './preview';
  import deepClone from './deep-clone';
  import Packager from '../packager/web/export';
  import Task from './task';
  import downloadURL from './download-url';
  import {recursivelySerializeBlobs, recursivelyDeserializeBlobs} from './blob-serializer';
  import {readAsText} from '../common/readers';
  import merge from './merge';
  import DropArea from './DropArea.svelte';
  import {APP_NAME} from '../packager/brand';
  import {logs, addLog, clearLogs} from './log';

  export let projectData;
  export let title;

  const cloudVariables = projectData.project.analysis.stageVariables
    .filter(i => i.isCloud)
    .map(i => i.name);

  const defaultOptions = Packager.DEFAULT_OPTIONS();
  defaultOptions.projectId = projectData.projectId || `p4-${projectData.uniqueId}`;
  for (const variable of cloudVariables) {
    defaultOptions.cloudVariables.custom[variable] = 'ws';
  }
  defaultOptions.app.packageName = Packager.getDefaultPackageNameFromFileName(projectData.title);
  defaultOptions.app.windowTitle = Packager.getWindowTitleFromFileName(projectData.title);
  const PREF_KEY = 'zx.prefs';
  const PREF_KEYS = [
    'turbo',
    'interpolation',
    'framerate',
    'highQualityPen',
    'maxClones',
    'autoplay',
    'compiler',
    'packagedRuntime',
    'target',
    'protect',
    'compression',
    'appearance',
    'stageWidth',
    'stageHeight',
    'resizeMode',
    'controls',
    'bakeExtensions',
    'maxTextureDimension'
  ];
  try {
    const stored = JSON.parse(localStorage.getItem(PREF_KEY) || 'null');
    if (stored) {
      for (const key of PREF_KEYS) {
        if (stored[key] !== undefined) {
          defaultOptions[key] = stored[key];
        }
      }
    }
  } catch (e) {}
  const savePrefs = () => {
    try {
      const data = {};
      for (const key of PREF_KEYS) {
        data[key] = $options[key];
      }
      localStorage.setItem(PREF_KEY, JSON.stringify(data));
    } catch (e) {}
  };
  let autoOpenFolder = true;
  try {
    autoOpenFolder = localStorage.getItem('zx.autoOpen') !== 'false';
  } catch (e) {}
  const saveAutoOpen = () => {
    try {
      localStorage.setItem('zx.autoOpen', autoOpenFolder ? 'true' : 'false');
    } catch (e) {}
  };
  const openOutputFolder = () => {
    if (!autoOpenFolder) {
      return;
    }
    if (window.chrome && window.chrome.webview) {
      window.chrome.webview.postMessage({
        action: 'openOutput'
      });
    }
  };
  const options = writablePersistentStore(`PackagerOptions.${projectData.uniqueId}`, defaultOptions);

  // Infinite clones used to be stored as a big number instead of actual `Infinity`.
  const ALMOST_INFINITY = 9999999999;
  if ($options.maxClones === ALMOST_INFINITY) {
    $options.maxClones = Infinity;
  }

  const hasMagicComment = (magic) => projectData.project.analysis.stageComments.find(
    (text) => text.split('\n').find((line) => line.endsWith(magic))
  );
  const hasSettingsStoredInProject = hasMagicComment(' // _twconfig_');

  let result = null;
  let previewer = null;
  const resetResult = () => {
    previewer = null;
    if (result) {
      URL.revokeObjectURL(result.url);
    }
    result = null;
  }
  $: if (previewer) {
    previewer.setProgress($progress.progress, $progress.text);
  }
  $: $options, resetResult(), currentTask.abort();

  const icon = fileStore.writableFileStore(`PackagerOptions.icon.${projectData.uniqueId}`);
  $: $options.app.icon = $icon;

  const customCursorIcon = fileStore.writableFileStore(`PackagerOptions.customCursorIcon.${projectData.uniqueId}`);
  $: $options.cursor.custom = $customCursorIcon;

  const loadingScreenImage = fileStore.writableFileStore(`PackagerOptions.loadingScreenImage.${projectData.uniqueId}`);
  $: $options.loadingScreen.image = $loadingScreenImage;

  const apkIcon = fileStore.writableFileStore(`PackagerOptions.apkIcon.${projectData.uniqueId}`);
  $: $options.apk.icon = $apkIcon;

  const exeIcon = fileStore.writableFileStore(`PackagerOptions.exeIcon.${projectData.uniqueId}`);
  $: $options.exe.icon = $exeIcon;

  $: title = $options.app.windowTitle;

  const setOptions = (newOptions) => {
    $options = newOptions;
    $icon = $options.app.icon;
    $customCursorIcon = $options.cursor.custom;
    $loadingScreenImage = $options.loadingScreen.image;
    $apkIcon = $options.apk.icon;
    $exeIcon = $options.exe.icon;
  };

  const otherEnvironmentsInitiallyOpen = ![
    'html',
    'zip',
    'electron-win32',
    'webview-mac',
    'electron-linux64'
  ].includes($options.target);

  const advancedOptionsInitiallyOpen = (
    $options.compiler.enabled !== defaultOptions.compiler.enabled ||
    $options.compiler.warpTimer !== defaultOptions.compiler.warpTimer ||
    $options.bakeExtensions !== defaultOptions.bakeExtensions ||
    $options.custom.css !== '' ||
    $options.custom.js !== '' ||
    $options.projectId !== defaultOptions.projectId ||
    $options.packagedRuntime !== defaultOptions.packagedRuntime ||
    $options.maxTextureDimension !== defaultOptions.maxTextureDimension
  );

  const automaticallyCenterCursor = () => {
    const icon = $customCursorIcon;
    const url = URL.createObjectURL(icon)
    const image = new Image();
    const cleanup = () => {
      image.onerror = null;
      image.onload = null;
      URL.revokeObjectURL(url);
    };
    image.onload = () => {
      $options.cursor.center.x = Math.round(image.width / 2);
      $options.cursor.center.y = Math.round(image.height / 2);
      cleanup();
    };
    image.onerror = () => {
      cleanup();
      $error = new Error('Image could not be loaded');
      throw $error;
    };
    image.src = url;
  };

  const runPackager = async (task, options, project) => {
    const packager = new Packager();
    packager.options = options;
    packager.project = project || projectData.project;

    task.addEventListener('abort', () => {
      packager.abort();
    });

    task.setProgressText($_('progress.loadingScripts'));

    packager.addEventListener('fetch-extensions', ({detail}) => {
      task.setProgressText($_('progress.downloadingExtensions'));
      task.setProgress(detail.progress);
    });
    packager.addEventListener('large-asset-fetch', ({detail}) => {
      let thing;
      if (detail.asset.startsWith('nwjs-')) {
        thing = 'NW.js';
      } else if (detail.asset.startsWith('electron-')) {
        thing = 'Electron';
      } else if (detail.asset === 'webview-mac') {
        thing = 'WKWebView';
      } else if (detail.asset === 'steamworks.js') {
        thing = 'Steamworks.js';
      }
      if (thing) {
        task.setProgressText($_('progress.loadingLargeAsset').replace('{thing}', thing));
      }
      task.setProgress(detail.progress);
    });
    packager.addEventListener('zip-progress', ({detail}) => {
      task.setProgressText($_('progress.compressingProject'));
      task.setProgress(detail.progress);
    });

    const result = await packager.package();
    result.blob = new Blob([result.data], {
      type: result.type
    });
    result.url = URL.createObjectURL(result.blob);
    return result;
  };

  const pack = async () => {
    resetResult();
    const task = new Task();
    const started = performance.now();
    addLog($_('zx.logStart').replace('{title}', $options.app.windowTitle).replace('{target}', $options.target));
    try {
      result = await task.do(runPackager(task, deepClone($options)));
      task.done();
      const elapsed = ((performance.now() - started) / 1000).toFixed(2);
      const size = (result.blob.size / 1000 / 1000).toFixed(2);
      addLog($_('zx.logDone').replace('{time}', elapsed).replace('{size}', size).replace('{file}', result.filename));
      savePrefs();
      downloadURL(result.filename, result.url);
      openOutputFolder();
    } catch (e) {
      addLog($_('zx.logFail').replace('{error}', e && e.message ? e.message : e));
      throw e;
    }
  };

  const preview = async () => {
    resetResult();
    previewer = new Preview();
    const task = new Task();
    const optionsClone = deepClone($options);
    optionsClone.target = 'html';
    try {
      result = await task.do(runPackager(task, optionsClone));
      task.done();
      previewer.setContent(result.blob, optionsClone.app.windowTitle);
    } catch (e) {
      previewer.close();
    }
  };

  const resetOptions = (properties) => {
    for (const key of properties) {
      let current = $options;
      let defaults = defaultOptions;
      const parts = key.split('.');
      const lastPart = parts.pop();
      for (const i of parts) {
        current = current[i];
        defaults = defaults[i];
      }
      current[lastPart] = deepClone(defaults[lastPart]);
    }
    $options = $options;
  };

  const resetAll = () => {
    if (confirm($_('reset.confirmAll'))) {
      resetOptions(Object.keys($options));
      $icon = null;
      $customCursorIcon = null;
      $loadingScreenImage = null;
    }
  };

  const applyPreset = (level, name) => {
    $options.compression.level = level;
    $options.protect.enabled = true;
    $options.bakeExtensions = true;
    $options = $options;
    addLog($_('zx.logPreset').replace('{name}', name).replace('{level}', level));
  };

  const exportOptions = async () => {
    const exported = await recursivelySerializeBlobs($options);
    const blob = new Blob([ExtendedJSON.stringify(exported)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const formattedAppName = APP_NAME
      .replace(/[^a-z0-9 ]/gi, '')
      .replace(/ /g, '-')
      .toLowerCase();
    downloadURL(`${formattedAppName}-settings.json`, url);
    URL.revokeObjectURL(url);
  };
    
  const importOptions = async () => {
    const input = document.createElement("input");
    input.type = 'file';
    input.accept = '.json';
    input.addEventListener('change', (e) => {
      importOptionsFromDataTransfer(e.target);
    });
    document.body.appendChild(input);
    input.click();
    input.remove();
  };

  const importOptionsFromDataTransfer = async (dataTransfer) => {
    const file = dataTransfer.files[0];
    if (!file) {
      // Should never happen.
      return;
    }
    try {
      const text = await readAsText(file);
      const parsed = ExtendedJSON.parse(text);
      const deserialized = recursivelyDeserializeBlobs(parsed);
      const copiedDefaultOptions = deepClone(defaultOptions);
      const mergedWithDefaults = merge(deserialized, copiedDefaultOptions);
      if (mergedWithDefaults.maxClones === ALMOST_INFINITY) {
        mergedWithDefaults.maxClones = Infinity;
      }

      const isUnsafe = Packager.usesUnsafeOptions(mergedWithDefaults);
      if (!isUnsafe || confirm($_('options.confirmImportUnsafe'))) {
        setOptions(mergedWithDefaults);
      }
    } catch (e) {
      $error = e;
    }
  };

  onDestroy(() => {
    if (result) {
      URL.revokeObjectURL(result.url);
    }
  });
</script>

<style>
  .option {
    display: block;
    margin: 4px 0;
  }
  .group {
    margin: 12px 0;
  }
  p {
    margin: 8px 0;
  }
  .group:last-child, .option:last-child, p:last-child {
    margin-bottom: 0;
  }
  textarea {
    box-sizing: border-box;
    width: 100%;
    min-width: 100%;
    height: 150px;
  }
  input[type="text"] {
    width: 200px;
  }
  input[type="text"].shorter {
    width: 150px;
  }
  .log-box {
    font-family: monospace;
    font-size: 0.8em;
    background: rgba(0, 0, 0, 0.06);
    border: 1px solid rgba(128, 128, 128, 0.25);
    padding: 8px;
    max-height: 240px;
    overflow: auto;
    white-space: pre-wrap;
    word-break: break-all;
  }
  input[type="number"] {
    width: 50px;
  }
  input:invalid, .version:placeholder-shown {
    outline: 2px solid red;
  }
  .warning {
    font-weight: bold;
    background: yellow;
    color: black;
    padding: 10px;
    border-radius: 10px;
  }
  .buttons {
    display: flex;
  }
  .button {
    margin-right: 4px;
  }
  .side-buttons {
    display: flex;
    margin-left: auto;
  }
</style>

<Section
  accent="#FFAB19"
  reset={() => {
    resetOptions([
      'turbo',
      'framerate',
      'interpolation',
      'highQualityPen',
      'maxClones',
      'fencing',
      'miscLimits',
      'stageWidth',
      'stageHeight',
      'resizeMode',
      'username'
    ]);
  }}
>
  <div>
    <h2>{$_('options.runtimeOptions')}</h2>

    {#if hasSettingsStoredInProject}
      <div class="group">
        {$_('options.storedWarning')}
      </div>
    {/if}

    <label class="option">
      <input type="checkbox" bind:checked={$options.turbo}>
      {$_('options.turbo')}
    </label>
    <div class="option">
      <label>
        {$_('options.framerate')}
        <input type="number" min="0" max="240" bind:value={$options.framerate}>
      </label>
      <LearnMore slug="custom-fps" />
    </div>
    <div class="option">
      <label>
        <input type="checkbox" bind:checked={$options.interpolation}>
        {$_('options.interpolation')}
      </label>
      <LearnMore slug="interpolation" />
    </div>
    <div class="option">
      <label>
        <input type="checkbox" bind:checked={$options.highQualityPen}>
        {$_('options.highQualityPen')}
      </label>
      <LearnMore slug="high-quality-pen" />
    </div>
    <div class="option">
      <label>
        <input type="checkbox" checked={$options.maxClones === Infinity} on:change={(e) => {
          $options.maxClones = e.target.checked ? Infinity : 300;
        }}>
        {$_('options.infiniteClones')}
      </label>
      <LearnMore slug="infinite-clones" />
    </div>
    <div class="option">
      <label>
        <input type="checkbox" checked={!$options.fencing} on:change={(e) => {
          $options.fencing = !e.target.checked;
        }}>
        {$_('options.removeFencing')}
      </label>
      <LearnMore slug="remove-fencing" />
    </div>
    <div class="option">
      <label>
        <input type="checkbox" checked={!$options.miscLimits} on:change={(e) => {
          $options.miscLimits = !e.target.checked;
        }}>
        {$_('options.removeMiscLimits')}
      </label>
      <LearnMore slug="remove-misc-limits" />
    </div>
    <label class="option">
      {$_('options.username')}
      <input type="text" class="shorter" bind:value={$options.username}>
    </label>
    {#if $options.username !== defaultOptions.username && cloudVariables.length !== 0}
      <p class="warning">
        {$_('options.customUsernameWarning')}
      </p>
    {/if}
    <label class="option">
      <input type="checkbox" bind:checked={$options.closeWhenStopped}>
      {$_('options.closeWhenStopped')}
    </label>

    <h3>{$_('options.stage')}</h3>
    <label class="option">
      {$_('options.stageSize')}
      <input type="number" min="1" max="4096" step="1" bind:value={$options.stageWidth}>
      &times;
      <input type="number" min="1" max="4096" step="1" bind:value={$options.stageHeight}>
      <LearnMore slug="custom-stage-size" />
    </label>
    <div class="group">
      <label class="option">
        <input type="radio" name="resize-mode" value="preserve-ratio" bind:group={$options.resizeMode}>
        {$_('options.preserveRatio')}
      </label>
      <label class="option">
        <input type="radio" name="resize-mode" value="stretch" bind:group={$options.resizeMode}>
        {$_('options.stretch')}
      </label>
      <label class="option">
        <input type="radio" name="resize-mode" value="dynamic-resize" bind:group={$options.resizeMode}>
        {$_('options.dynamicResize')}
        <LearnMore slug="packager/dynamic-stage-resize" />
      </label>
    </div>
  </div>
</Section>

<Section
  accent="#9966FF"
  reset={() => {
    $icon = null;
    $loadingScreenImage = null;
    resetOptions([
      'app.windowTitle',
      'loadingScreen',
      'autoplay',
      'controls',
      'appearance',
      'monitors',
    ]);
  }}
>
  <div>
    <h2>{$_('options.playerOptions')}</h2>

    <label class="option">
      {$_('options.pageTitle')}
      <input type="text" bind:value={$options.app.windowTitle}>
    </label>
    <div class="option">
      {$_('options.icon')}
      <ImageInput bind:file={$icon} previewSizes={[[64, 64], [32, 32], [16, 16]]} />
    </div>

    <h3>{$_('options.loadingScreen')}</h3>
    <label class="option">
      <input type="checkbox" bind:checked={$options.loadingScreen.progressBar}>
      {$_('options.showProgressBar')}
    </label>
    <label class="option">
      {$_('options.loadingScreenText')}
      <input type="text" bind:value={$options.loadingScreen.text} placeholder={$_('options.loadingScreenTextPlaceholder')}>
    </label>
    <div class="option">
      {$_('options.loadingScreenImage')}
      <!-- Display preview at image's native size -->
      <ImageInput bind:file={$loadingScreenImage} previewSizes={[['', '']]} />
    </div>
    {#if $loadingScreenImage}
      <label class="option">
        <input type="radio" name="loading-screen-mode" value="normal" bind:group={$options.loadingScreen.imageMode}>
        {$_('options.sizeNormal')}
      </label>
      <label class="option">
        <input type="radio" name="loading-screen-mode" value="stretch" bind:group={$options.loadingScreen.imageMode}>
        {$_('options.sizeStretch')}
      </label>
    {/if}

    <h3>{$_('options.controls')}</h3>
    <div class="group">
      <label class="option">
        <input type="checkbox" bind:checked={$options.autoplay}>
        {$_('options.autoplay')}
      </label>
      {#if $options.autoplay}
        {$_('options.autoplayHint')}
      {/if}
    </div>
    <label class="option">
      <input type="checkbox" bind:checked={$options.controls.greenFlag.enabled}>
      {$_('options.showFlag')}
    </label>
    <label class="option">
      <input type="checkbox" bind:checked={$options.controls.stopAll.enabled}>
      {$_('options.showStop')}
    </label>
    <label class="option">
      <input type="checkbox" bind:checked={$options.controls.pause.enabled}>
      {$_('options.showPause')}
    </label>
    <label class="option">
      <input type="checkbox" bind:checked={$options.controls.fullscreen.enabled}>
      {$_('options.showFullscreen')}
    </label>
    <p>{$_('options.controlsHelp')}</p>

    <h3>{$_('options.colors')}</h3>
    <!-- svelte-ignore a11y-label-has-associated-control -->
    <label class="option">
      <ColorPicker bind:value={$options.appearance.background} />
      {$_('options.backgroundColor')}
    </label>
    <!-- svelte-ignore a11y-label-has-associated-control -->
    <label class="option">
      <ColorPicker bind:value={$options.appearance.foreground} />
      {$_('options.foregroundColor')}
    </label>
    <!-- svelte-ignore a11y-label-has-associated-control -->
    <label class="option">
      <ColorPicker bind:value={$options.appearance.accent} />
      {$_('options.accentColor')}
    </label>

    <h3>{$_('options.monitors')}</h3>
    <label class="option">
      <input type="checkbox" bind:checked={$options.monitors.editableLists}>
      {$_('options.editableLists')}
    </label>
    <!-- svelte-ignore a11y-label-has-associated-control -->
    <label class="option">
      <ColorPicker bind:value={$options.monitors.variableColor} />
      {$_('options.variableColor')}
    </label>
    <!-- svelte-ignore a11y-label-has-associated-control -->
    <label class="option">
      <ColorPicker bind:value={$options.monitors.listColor} />
      {$_('options.listColor')}
    </label>
  </div>
</Section>

<Section
  accent="#4CBFE6"
  reset={() => {
    $customCursorIcon = null;
    resetOptions([
      'cursor',
      'chunks',
    ]);
  }}
>
  <div>
    <h2>{$_('options.interaction')}</h2>
    <div class="group">
      <label class="option">
        <input type="radio" name="cursor-type" bind:group={$options.cursor.type} value="auto">
        {$_('options.normalCursor')}
      </label>
      <label class="option">
        <input type="radio" name="cursor-type" bind:group={$options.cursor.type} value="none">
        {$_('options.noCursor')}
      </label>
      <label class="option">
        <input type="radio" name="cursor-type" bind:group={$options.cursor.type} value="custom">
        {$_('options.customCursor')}
      </label>
    </div>
    {#if $options.cursor.type === 'custom'}
      <div in:slide|self class="option">
        <ImageInput bind:file={$customCursorIcon} previewSizes={[[32, 32], [16, 16]]} />
        <p>{$_('options.cursorHelp')}</p>
        <label class="option">
          {$_('options.cursorCenter')}
          <!-- X: and Y: intentionally not translated -->
          X: <input type="number" min="0" bind:value={$options.cursor.center.x}>
          Y: <input type="number" min="0" bind:value={$options.cursor.center.y}>
          <button
            on:click={automaticallyCenterCursor}
            disabled={!$customCursorIcon}
          >
            {$_('options.automaticallyCenter')}
          </button>
        </label>
      </div>
    {/if}

    <div class="group">
      <label class="option">
        <input type="checkbox" bind:checked={$options.chunks.pointerlock}>
        {$_('options.pointerlock')}
      </label>
      <a href="https://experiments.turbowarp.org/pointerlock/" target="_blank" rel="noopener noreferrer">
        {$_('options.pointerlockHelp')}
      </a>
    </div>

    <div class="group">
      <label class="option">
        <input type="checkbox" bind:checked={$options.chunks.gamepad}>
        {$_('options.gamepad')}
      </label>
      <a href="https://turbowarp.org/addons#gamepad" target="_blank" rel="noopener noreferrer">
        {$_('options.gamepadHelp')}
      </a>
    </div>
  </div>
</Section>

<Section
  accent="#FF8C1A"
  reset={cloudVariables.length === 0 ? null : () => {
    resetOptions([
      'cloudVariables'
    ]);
  }}
>
  <div>
    <h2>{$_('options.cloudVariables')}</h2>

    {#if cloudVariables.length > 0}
      <label class="option">
        {$_('options.mode')}
        <select bind:value={$options.cloudVariables.mode}>
          <option value="ws">{$_('options.cloudVariables-ws')}</option>
          <option value="local">{$_('options.cloudVariables-local')}</option>
          <option value="">{$_('options.cloudVariables-ignore')}</option>
          <option value="custom">{$_('options.cloudVariables-custom')}</option>
        </select>
      </label>

      {#if $options.cloudVariables.mode === "custom"}
        <div transition:fade|local>
          {#each cloudVariables as variable}
            <label class="option">
              <select bind:value={$options.cloudVariables.custom[variable]}>
                <option value="ws">{$_('options.cloudVariables-ws')}</option>
                <option value="local">{$_('options.cloudVariables-local')}</option>
                <option value="">{$_('options.cloudVariables-ignore')}</option>
              </select>
              {variable}
            </label>
          {/each}
        </div>
      {/if}

      {#if $options.cloudVariables.mode === 'ws' || $options.cloudVariables.mode === 'custom'}
        <div transition:fade|local>
          <label class="option">
            {$_('options.cloudVariablesHost')}
            <!-- Examples of valid values: -->
            <!-- wss://clouddata.turbowarp.org -->
            <!-- ws:localhost:8080 -->
            <input type="text" bind:value={$options.cloudVariables.cloudHost} pattern="wss?:.*">
          </label>
        </div>
      {/if}

      <p>{$_('options.cloudVariables-ws-help')}</p>
      <p>{$_('options.cloudVariables-local-help')}</p>
      <p>{$_('options.cloudVariables-ignore-help')}</p>
      <p>{$_('options.cloudVariables-custom-help')}</p>

      <div class="option">
        <label>
          <input type="checkbox" bind:checked={$options.cloudVariables.specialCloudBehaviors}>
          {$_('options.specialCloudBehaviors')}
        </label>
        <LearnMore slug="packager/special-cloud-behaviors" />
      </div>

      <div class="option">
        <label>
          <input type="checkbox" bind:checked={$options.cloudVariables.unsafeCloudBehaviors}>
          {$_('options.unsafeCloudBehaviors')}
        </label>
        <LearnMore slug="packager/special-cloud-behaviors#eval" />
      </div>
      {#if $options.cloudVariables.unsafeCloudBehaviors}
        <p class="warning">{$_('options.unsafeCloudBehaviorsWarning')}</p>
      {/if}
      <p>{$_('options.implicitCloudHint').replace('{cloud}', '☁')}</p>
    {:else}
      <p>{$_('options.noCloudVariables')}</p>
    {/if}
  </div>
</Section>

<Section
  accent="#FF6680"
  reset={() => {
    resetOptions([
      'compiler',
      'bakeExtensions',
      'custom',
      'projectId',
      'maxTextureDimension'
    ]);
  }}
>
  <div>
    <h2>{$_('options.advancedOptions')}</h2>
    <details open={advancedOptionsInitiallyOpen}>
      <summary>{$_('options.advancedSummary')}</summary>

      <div class="option">
        <label>
          <input type="checkbox" bind:checked={$options.compiler.enabled}>
          {$_('options.enableCompiler')}
        </label>
        <LearnMore slug="disable-compiler" />
      </div>
      <div class="option">
        <label>
          <input type="checkbox" bind:checked={$options.compiler.warpTimer}>
          {$_('options.warpTimer')}
        </label>
        <LearnMore slug="warp-timer" />
      </div>

      <label class="option">
        <input type="checkbox" bind:checked={$options.bakeExtensions}>
        {$_('options.bakeExtensions')}
      </label>

      <label class="option">
        {$_('options.customCSS')}
        <textarea bind:value={$options.custom.css}></textarea>
      </label>
      <label class="option">
        {$_('options.customJS')}
        <textarea bind:value={$options.custom.js}></textarea>
      </label>

      <label class="option">
        {$_('options.projectId')}
        <input type="text" bind:value={$options.projectId}>
      </label>
      <p>{$_('options.projectIdHelp')}</p>

      <label class="option">
        <input type="checkbox" bind:checked={$options.packagedRuntime} />
        {$_('options.packagedRuntime')}
      </label>

      <label class="option">
        <input type="checkbox" checked={$options.maxTextureDimension !== defaultOptions.maxTextureDimension} on:change={(e) => {
          $options.maxTextureDimension = defaultOptions.maxTextureDimension * (e.target.checked ? 2 : 1);
        }} />
        {$_('options.maxTextureDimension')}
      </label>
    </details>
  </div>
</Section>

<Section accent="#14a0ff">
  <div>
    <h2>{$_('zx.presetsTitle')}</h2>
    <div class="buttons">
      <div class="button">
        <Button on:click={() => applyPreset(1, $_('zx.presetFast'))} secondary text={$_('zx.presetFast')} />
      </div>
      <div class="button">
        <Button on:click={() => applyPreset(6, $_('zx.presetNormal'))} secondary text={$_('zx.presetNormal')} />
      </div>
      <div class="button">
        <Button on:click={() => applyPreset(9, $_('zx.presetMax'))} secondary text={$_('zx.presetMax')} />
      </div>
    </div>
    <p>{$_('zx.presetsHelp')}</p>
  </div>
</Section>

<Section
  accent="#0FBD8C"
  reset={() => {
    resetOptions([
      'target'
    ])
  }}
>
  <div>
    <h2>{$_('options.environment')}</h2>

    <div class="group">
      <label class="option">
        <input type="radio" name="environment" bind:group={$options.target} value="html">
        {$_('options.html')}
      </label>
      <label class="option">
        <input type="radio" name="environment" bind:group={$options.target} value="zip">
        {$_('options.zip')}
      </label>
      <label class="option">
        <input type="radio" name="environment" bind:group={$options.target} value="apk">
        {$_('zx.targetApk')}
      </label>
      <label class="option">
        <input type="radio" name="environment" bind:group={$options.target} value="exe">
        {$_('zx.targetExe')}
      </label>
    </div>

    <div class="group">
      <label class="option">
        <input type="radio" name="environment" bind:group={$options.target} value="electron-win32">
        {$_('options.application-win32').replace('{type}', 'Electron')}
      </label>
      <label class="option">
        <input type="radio" name="environment" bind:group={$options.target} value="webview-mac">
        {$_('options.application-mac').replace('{type}', 'WKWebView')}
      </label>
      <label class="option">
        <input type="radio" name="environment" bind:group={$options.target} value="electron-linux64">
        {$_('options.application-linux64').replace('{type}', 'Electron')}
      </label>
    </div>

    <details open={otherEnvironmentsInitiallyOpen}>
      <summary>{$_('options.otherEnvironments')}</summary>
      <p>{$_('options.otherEnvironmentsHelp')}</p>
      <div class="group">
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="zip-one-asset">
          {$_('options.zip-one-asset')}
        </label>
      </div>
      <div class="group">
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="electron-win64">
          {$_('options.application-win64').replace('{type}', 'Electron')}
        </label>
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="electron-win-arm">
          {$_('options.application-win-arm').replace('{type}', 'Electron')}
        </label>
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="electron-mac">
          {$_('options.application-mac').replace('{type}', 'Electron')}
        </label>
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="electron-linux-arm32">
          {$_('options.application-linux-arm32').replace('{type}', 'Electron')}
        </label>
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="electron-linux-arm64">
          {$_('options.application-linux-arm64').replace('{type}', 'Electron')}
        </label>  
      </div>

      <div class="group">
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="nwjs-win32">
          {$_('options.application-win32').replace('{type}', 'NW.js')}
        </label>
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="nwjs-win64">
          {$_('options.application-win64').replace('{type}', 'NW.js')}
        </label>
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="nwjs-mac">
          {$_('options.application-mac').replace('{type}', 'NW.js')}
        </label>
        <label class="option">
          <input type="radio" name="environment" bind:group={$options.target} value="nwjs-linux-x64">
          {$_('options.application-linux64').replace('{type}', 'NW.js')}
        </label>
      </div>
    </details>
  </div>
</Section>

<Section accent="#7a5cff">
  <div>
    <h2>{$_('zx.protectTitle')}</h2>
    <label class="option">
      <input type="checkbox" bind:checked={$options.protect.enabled} />
      {$_('zx.protectEnable')}
    </label>
    <label class="option">
      {$_('zx.protectKey')}
      <input type="text" bind:value={$options.protect.key} placeholder={$_('zx.protectKeyPlaceholder')}>
    </label>
    <label class="option">
      {$_('zx.protectWatermark')}
      <input type="text" bind:value={$options.protect.watermark} placeholder={$_('zx.protectWatermarkPlaceholder')}>
    </label>
    <p>{$_('zx.protectHelp')}</p>
  </div>
</Section>

{#if $options.target === 'apk'}
  <Section accent="#0FBD8C" reset={() => resetOptions(['apk'])}>
    <h2>{$_('zx.apkSettings')}</h2>
    <label class="option">
      {$_('zx.apkPackage')}
      <input type="text" bind:value={$options.apk.packageName}>
    </label>
    <label class="option">
      {$_('zx.apkAppName')}
      <input type="text" bind:value={$options.apk.appName}>
    </label>
    <label class="option">
      {$_('zx.apkVersionName')}
      <input type="text" bind:value={$options.apk.versionName}>
    </label>
    <label class="option">
      {$_('zx.apkVersionCode')}
      <input type="number" min="1" bind:value={$options.apk.versionCode}>
    </label>
    <label class="option">
      {$_('zx.apkOrientation')}
      <select bind:value={$options.apk.orientation}>
        <option value="sensorLandscape">{$_('zx.orientation_sensorLandscape')}</option>
        <option value="landscape">{$_('zx.orientation_landscape')}</option>
        <option value="portrait">{$_('zx.orientation_portrait')}</option>
        <option value="fullSensor">{$_('zx.orientation_fullSensor')}</option>
      </select>
    </label>
    <label class="option">
      {$_('zx.apkMinSdk')}
      <select bind:value={$options.apk.minSdk}>
        <option value={21}>API 21</option>
        <option value={23}>API 23</option>
        <option value={24}>API 24</option>
        <option value={26}>API 26</option>
      </select>
    </label>
    <div style="margin-top: 8px">
      <ImageInput bind:file={$apkIcon} previewSizes={[[48, 48], [192, 192]]} />
    </div>
    <p>{$_('zx.apkLine1')}</p>
    <p>{$_('zx.apkLine3')}</p>
  </Section>
{/if}

{#if $options.target === 'exe'}
  <Section accent="#0FBD8C" reset={() => resetOptions(['exe'])}>
    <h2>{$_('zx.exeSettings')}</h2>
    <label class="option">
      {$_('zx.exeName')}
      <input type="text" bind:value={$options.exe.name} placeholder="{$options.app.windowTitle}">
    </label>
    <label class="option">
      {$_('zx.exeVersion')}
      <input type="text" bind:value={$options.exe.version}>
    </label>
    <div style="margin-top: 8px">
      <div>{$_('zx.exeIcon')}</div>
      <ImageInput bind:file={$exeIcon} previewSizes={[[32, 32], [64, 64], [128, 128]]} />
    </div>
  </Section>
{/if}

{#if $options.target !== 'html' && $options.target !== 'apk' && $options.target !== 'exe'}
  <div in:fade|local>
    <Section
      accent="#FF661A"
      reset={$options.target.startsWith('zip') ? null : () => {
        resetOptions([
          'app.packageName',
          'app.windowMode',
          'app.escapeBehavior',
          'app.backgroundThrottling'
        ]);
      }}
    >
      <div>
        {#if $options.target.startsWith('zip')}
          <h2>Zip</h2>
          <p>The zip environment is intended to be used for publishing to a website. Other uses such as sending your project to a friend over a chat app or email should use "Plain HTML" instead as zip will not work.</p>
        {:else}
          <h2>{$_('options.applicationSettings')}</h2>
          <label class="option">
            {$_('options.packageName')}
            <input type="text" bind:value={$options.app.packageName} pattern="[\w \-]+" minlength="1">
          </label>
          <p>{$_('options.packageNameHelp')}</p>

          <label class="option">
            {$_('options.version')}
            <input type="text" class="version" bind:value={$options.app.version} pattern="\d+\.\d+\.\d+" placeholder="1.0.0" minlength="1">
          </label>
          <p>{$_('options.versionHelp')}</p>

          {#if $options.target.includes('electron')}
            <label class="option">
              {$_('options.initalWindowSize')}
              <select bind:value={$options.app.windowMode}>
                <option value="window">{$_('options.startWindow')}</option>
                <option value="maximize">{$_('options.startMaximized')}</option>
                <option value="fullscreen">{$_('options.startFullscreen')}</option>
              </select>
            </label>

            <label class="option">
              {$_('options.escapeBehavior')}
              <select bind:value={$options.app.escapeBehavior}>
                <option value="unfullscreen-only">{$_('options.unFullscreenOnly')}</option>
                <option value="exit-only">{$_('options.exitOnly')}</option>
                <option value="unfullscreen-or-exit">{$_('options.unFullscreenOrExit')}</option>
                <option value="nothing">{$_('options.doNothing')}</option>
              </select>
            </label>

            <label class="option">
              {$_('options.windowControls')}
              <select bind:value={$options.app.windowControls}>
                <option value="default">{$_('options.defaultControls')}</option>
                <option value="frameless">{$_('options.noControls')}</option>
              </select>
            </label>

            <label class="option">
              <input type="checkbox" bind:checked={$options.app.backgroundThrottling}>
              {$_('options.backgroundThrottling')}
            </label>
          {/if}

          <div class="warning">
            <div>Creating native applications for specific platforms is discouraged. In most cases, Plain HTML or Zip will have numerous advantages:</div>
            <ul>
              <li>Can be run directly from a website on any platform, even phones</li>
              <li>Users are significantly less likely to be suspicious of a virus</li>
              <li>Significantly smaller file size</li>
              <li>Can still be downloaded locally and run offline</li>
            </ul>
            <div>If you don't truly need to make a self-contained application for each platform (we understand there are some cases where this is necessary), we recommend you don't.</div>
          </div>

          {#if $options.target.includes('win')}
            <div>
              <h2>Windows</h2>
              <p>All Windows applications generated by this site are unsigned, so users will see SmartScreen warnings when they try to run it for the first time. They can bypass these warnings by pressing "More info" then "Run anyways".</p>
              <p>To change the icon of the executable file or create an installer program, download and run <a href="https://github.com/TurboWarp/packager-extras/releases">TurboWarp Packager Extras</a> and select the output of this website.</p>
            </div>
          {:else if $options.target.includes('mac')}
            <div>
              <h2>macOS</h2>
              <p>Due to Apple policy, packaging for their platforms is troublesome. You either have to:</p>
              <ul>
                <li>Instruct users to ignore scary Gatekeeper warnings by opening Finder > Navigating to the application > Right click > Open > Open. This website generates applications that require this workaround.</li>
                <li>Or pay Apple $100/year for a developer account to sign and notarize the app (very involved process; reach out in feedback for more information)</li>
              </ul>
            </div>
          {:else if $options.target.includes('linux')}
            <div>
              <h2>Linux</h2>
              <p>Linux support is still experimental.</p>
            </div>
          {/if}

          {#if $options.target.includes('electron')}
            <div>
              <h2>Electron</h2>
              <p>The Electron environment works by embedding a copy of Chromium (the open source part of Google Chrome) along with your project, which means the app will be very large.</p>

              {#if $options.target.includes('win')}
                {#if $options.target.includes('32')}
                  <p>Note: You have selected the 32-bit or 64-bit mode. This maximizes device compatibility but limits the amount of memory the app can use. If you encounter crashes, try going into "Other environments" and using the 64-bit only mode instead.</p>
                {/if}
              {:else if $options.target.includes('mac')}
                <p>On macOS, the app will run natively on both Intel Silicon and Apple Silicon Macs.</p>
              {:else if $options.target.includes('linux')}
                <p>On Linux, the application can be started by running <code>start.sh</code></p>
              {/if}
            </div>
          {:else if $options.target.includes('nwjs')}
            <div>
              <h2>NW.js</h2>
              <p>The NW.js environment works by embedding a copy of Chromium (the open source part of Google Chrome) along with your project, which means the app will be very large.</p>
              <p>For further help and steps, see <a href="https://docs.nwjs.io/en/latest/For%20Users/Package%20and%20Distribute/#linux">NW.js Documentation</a>.</p>
              {#if $options.target.includes('mac')}
                <p>On macOS, the app will run using Rosetta on Apple Silicon Macs.</p>
              {/if}
            </div>
          {:else if $options.target.includes('webview-mac')}
            <div>
              <h2>WKWebView</h2>
              <p>WKWebView is the preferred way to package for macOS. It will be hundreds of MB smaller than the other macOS-specific environments and typically run the fastest.</p>
              <p>The app will run natively on both Intel and Apple silicon Macs running macOS 10.13 or later.</p>
              <p>Note that:</p>
              <ul>
                <li>Video sensing and loudness blocks will only work in macOS 12 or later.</li>
                <li>Pointer lock will not work.</li>
                <li>Extremely large projects might not work properly.</li>
              </ul>
              <p>Use the "Electron macOS Application" (inside Other environments) or "Plain HTML" environments instead if you encounter these issues.</p>
            </div>
          {/if}
        {/if}
      </div>
    </Section>
  </div>
{/if}

{#if projectData.project.analysis.usesSteamworks}
  <Section
    accent="#136C9F"
    reset={() => {
      resetOptions([
        'steamworks'
      ]);
    }}
  >
    <h2>{$_('options.steamworksExtension')}</h2>
    {#if ['electron-win64', 'electron-linux64', 'electron-mac'].includes($options.target)}
      <p>{$_('options.steamworksAvailable').replace('{n}', '480')}</p>
      <label class="option">
        {$_('options.steamworksAppId')}
        <input pattern="\d+" minlength="1" bind:value={$options.steamworks.appId}>
      </label>
      <label class="option">
        {$_('options.steamworksOnError')}
        <select bind:value={$options.steamworks.onError}>
          <option value="ignore">{$_('options.steamworksIgnore')}</option>
          <option value="warning">{$_('options.steamworksWarning')}</option>
          <option value="error">{$_('options.steamworksError')}</option>
        </select>
      </label>

      {#if $options.target === 'electron-mac'}
        <p class="warning">
          {$_('options.steamworksMacWarning')}
        </p>
      {/if}
    {:else}
      <p>{$_('options.steamworksUnavailable')}</p>
      <ul>
        <li>{$_('options.application-win64').replace('{type}', 'Electron')}</li>
        <li>
          {$_('options.application-mac').replace('{type}', 'Electron')}
          <br>
          {$_('options.steamworksMacWarning')}
        </li>
        <li>{$_('options.application-linux64').replace('{type}', 'Electron')}</li>
      </ul>
    {/if}

    <p>
      <a href="https://extensions.turbowarp.org/steamworks">{$_('options.steamworksDocumentation')}</a>
    </p>
  </Section>
{/if}

<Section>
  <DropArea on:drop={(e) => importOptionsFromDataTransfer(e.detail)}>
    <div class="buttons">
      <div class="button">
        <Button on:click={exportOptions} secondary text={$_('options.export')} />
      </div>
      <div class="button">
        <Button on:click={importOptions} secondary text={$_('options.import')} />
      </div>
      <div class="side-buttons">
        <Button on:click={resetAll} dangerous text={$_('options.resetAll')} />
      </div>
    </div>
  </DropArea>
</Section>

<Section>
  <div class="buttons">
    <div class="button">
      <Button on:click={pack} text={$_('options.package')} />
    </div>
    <div clas="button">
      <Button on:click={preview} secondary text={$_('options.preview')} />
    </div>
  </div>
  <label class="option">
    <input type="checkbox" bind:checked={autoOpenFolder} on:change={saveAutoOpen} />
    {$_('zx.autoOpen')}
  </label>
</Section>

<Section>
  <h2>{$_('zx.logsTitle')}</h2>
  <div class="buttons">
    <div class="button">
      <Button on:click={() => navigator.clipboard.writeText($logs.join('\n'))} secondary text={$_('zx.logsCopy')} />
    </div>
    <div class="button">
      <Button on:click={clearLogs} dangerous text={$_('zx.logsClear')} />
    </div>
  </div>
  <div class="log-box">{$logs.length ? $logs.join('\n') : $_('zx.logsEmpty')}</div>
</Section>

{#if result}
  <Downloads
    name={result ? result.filename : null}
    url={result ? result.url : null}
    blob={result ? result.blob : null}
  />
{:else if !$progress.visible}
  <Section caption>
    <p>{$_('options.downloadsWillAppearHere')}</p>
  </Section>
{/if}
